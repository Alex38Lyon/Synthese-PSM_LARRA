Caves' surveys of Koyten-dag (Turkmenistan)
===========================================

Overview
--------

This repository contains survey's data from Turkmenistan caves surveyed by the french expedition Koyten-dag 2024.


Description
-----------

This repository stores the surveys database of the caves in Koyten-dag (Turkmenistan). The files are for Therion (data + drawings) software.

Only the source files are backup :
	
	* .thc, .th, .th2 and .thconfig for Therion Software
	
To get the surveys you need to compile the Therion files.

The caving report will be soon available on `_https://www.groupe-speleo-vulcain.com/explorations/expeditions-a-letranger/`

Licence
-------

Released under a Creative Commons Attribution-ShareAlike-NonCommecial License:
	<http://creativecommons.org/licenses/by-nc-sa/4.0/>

Database conception authors
---------------------------

Xavier Robert and Alexandre Pont

How to cite
-----------
